 <!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="style/style.css"><!--inclure le css-->
        <title>Connexion</title>
    </head>

    <body id="content">

        <?php
            // connexion à la base de données MySQL
            include 'connexionbd.php';

            session_start();

            if(isset($_POST["utilisateur"], $_POST["mdp"]))//si l'utilisateur a entre des valeurs dans les champs de textes
            {

                $utilisateur = mysqli_real_escape_string($connexion, $_POST["utilisateur"]);
                $mdp = mysqli_real_escape_string($connexion, $_POST["mdp"]);

                //verifie si les valeur entrees par l'utilisateur correspondent a un compte existant
                $requete = "SELECT * FROM table_login WHERE utilisateur='{$utilisateur}' and mot_de_passe='{$mdp}'";
                $resultat = mysqli_query($connexion,$requete) or die ("Exécution de la requête impossible ".mysqli_error($connexion));
                
                $rows = mysqli_num_rows($resultat);//nombre de lignes trouvees

                if($rows==1)//si une ligne est trouvee
                {
                    $_SESSION['utilisateur'] = $utilisateur;//ouvre la session de l'utilisateur
                    header("Location: index.php");//redirige vers index.php
                }
//Systeme de sauvegarde des caractères entrés//
                else
                {
                    $_SESSION['utilisateur'] = $_POST['utilisateur'];
                    $_SESSION['mdp'] = $_POST['mdp'];
                    $_SESSION['error'] = true;            
                }
            }
            else
            {
                $_SESSION['utilisateur'] = "";
                $_SESSION['mdp'] = "";
                $_SESSION['error']=false;
            }
////////////////////////////////////////////////
            // Déconnexion
            mysqli_close($connexion);
        ?>
        <h1>Se connecter : </h1>
        <div id="form">
            <form method="post" action="connexion.php">

                <p>
                    Nom d'utilisateur :             
                    <?php
                        print('<input type="text" name="utilisateur" value="'.$_SESSION["utilisateur"].'" autofocus required>');
                    ?>
                </p>
                <p>
                    Mot de passe :             
                    <?php
                        print('<input type="password" name="mdp" value="'.$_SESSION["mdp"].'" autofocus required>');
                    ?>
                </p>
                <?php
                    if($_SESSION['error'])print("<h4 id='redom'>Nom d'utilisateur ou mot de passe incorrect<h4>");
                ?>
                <input class="button" type="submit" value="Connexion">
            </form>
            <form method="post" action="inscription.php">
                <input class="button" type="submit" value="S'inscrire">
            </form>
        </div>
    </body>
</html> 