<?php

    session_start();

    if(!isset($_SESSION["utilisateur"]))
    {
        header("Location: connexion.php");
        exit();
    }
?>

<!DOCTYPE html>


<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="style/style.css"><!--inclure le css-->
        <title>Questionnaire</title>
    </head>
	
    <?php

        include 'connexionbd.php';

        $connexion = mysqli_connect($MYSQL_SERVER,$MYSQL_USER,$MYSQL_PASSWORD,$DATABASE);

        if(isset($_POST["choix"]))//verifie si une case est cochee
        {

            $choix = $_POST["choix"];
            
            
            //$requete = "INSERT INTO table_login (utilisateur,choix) VALUES ('{$_SESSION["utilisateur"]}','{$choix}')";
            $requete = "UPDATE table_login SET choix = '{$choix}' WHERE utilisateur = '{$_SESSION["utilisateur"]}'";

            $resultat = mysqli_query($connexion,$requete) or die ("Exécution de la requête impossible ".mysqli_error($connexion));

            if($resultat===TRUE)
            {
                header('Location: stats.php');
            }
        }    
            // Déconnexion
        mysqli_close($connexion);
    ?>
	
    <body id="content">
        <div id="form">
            <h1>Voter :</h1>
            <form method="post" action="questionnaire.php">
                <div id="group">
                    <p>
                        <input type="radio" name="choix" value="Barcelone" autofocus required> Barcelone<br>
                        <img id="logoclub" src="img/Barcelone.png"/>
                    </p>
                    <p>
                        <input type="radio" name="choix" value="Real_Madrid" autofocus required checked> Real Madrid<br>
                        <img id="logoclub" src="img/Real_Madrid.png"/>
                    </p>					
                </div>
                <input class="button" type="submit" value="Valider">
            </form>
            <form method="post" action="deconnexion.php">
                <input class="button" type="submit" value="Deconnexion">
            </form>
        </div>
    </body>
</html> 