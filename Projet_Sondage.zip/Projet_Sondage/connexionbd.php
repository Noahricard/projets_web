<?php
	$MYSQL_SERVER = "localhost";
    $MYSQL_USER = "root";
    $MYSQL_PASSWORD = "";

    $DATABASE = "projet_sondage";
    $TABLE = "table_login";

    $connexion = mysqli_connect($MYSQL_SERVER,$MYSQL_USER,$MYSQL_PASSWORD,$DATABASE);
?>