<?php
    session_start();

    if(isset($_SESSION["utilisateur"]) && $_SESSION["utilisateur"]!="" && !$_SESSION['error'])
    {
        header("Location: index.php");
        exit();
    }
?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="style/style.css"><!--inclure le css-->
        <title>Inscription</title>
    </head>

    <body id="content">
            <h1>Créer un compte :</h1>
            <div id="form">
                <form method="post" action="inscription.php">
                    <p>Nom d'utilisateur : <input type="text" name="utilisateur" autofocus required></p>
                    <p>Mot de passe : <input type="password" name="mdp" autofocus required></p>
                    <p> Nom : <input type="text" name="nom" autofocus required></p>
                    <p>Prénom : <input type="text" name="prenom" autofocus required></p>
                    <p>Code postal(0 si à l'étranger) : <input type="text" name="cp" autofocus required></p>
                    <p>Date de naissance <i>(AAAA/MM/JJ)</i> : <input type="text" name="date" autofocus required></p> 
                    <p>
                        <input id="radio" type="radio" name="sexe" value="femme" autofocus required checked> Femme           
                        <input id="radio" type="radio" name="sexe" value="homme" autofocus required> Homme
                    </p>
                    <input class="button" type="submit" value="Inscription">
                </form>
                <form method="post" action="connexion.php">
                    <input class="button" type="submit" value="Se Connecter">
                </form>
            </div>
            <?php
                // connexion à la base de données MySQL
                function isDateValid($date){
                    $error = false;
                    try
                    {
                        $dt = DateTime::createFromFormat('Y-m-d', $date);
                        $dt && $dt->format('Y-m-d') === $date;
                        $date = date_diff(date_create($date),date_create(date("Y-m-d")));
                        $date = $date->format('%R%a');
                        if($date < 0 OR $date > 45580)
                        {
                            $error=true;
                        }

                    } catch (Exception $e)
                    {
                        $error = true;
                    }
                    return $error;
                }
                // paramètres de connexion par défaut
                include 'connexionbd.php';

                if(isset($_POST["utilisateur"], $_POST["mdp"], $_POST["nom"], $_POST["prenom"], $_POST["date"], $_POST["sexe"], $_POST["cp"]))//verifie si tous les champs sont remplis
                {

                    $utilisateur = mysqli_real_escape_string($connexion, $_POST["utilisateur"]);
                    $mdp = mysqli_real_escape_string($connexion, $_POST["mdp"]);
                    $nom = mysqli_real_escape_string($connexion, $_POST["nom"]);
                    $prenom = mysqli_real_escape_string($connexion, $_POST["prenom"]);
                    $date_naissance = mysqli_real_escape_string($connexion, $_POST["date"]);
                    $cp = mysqli_real_escape_string($connexion, $_POST["cp"]);
                    $sexe = mysqli_real_escape_string($connexion, $_POST["sexe"]);

                    $erreur=false;

                    $date = date_create($date_naissance);
                    
                    $requete = "SELECT utilisateur FROM table_login WHERE utilisateur = '{$utilisateur}'";
                    $resultat = mysqli_query($connexion,$requete) or die ("Exécution de la requête impossible ".mysqli_error($connexion));

                    if(mysqli_num_rows($resultat)==1)
                    {
                        print("<br>Nom d'utilisateur déjà utilisé, veuillez en choisir un autre");
                        $erreur=true;
                    }

                    if($date === false)//regarde
                    {
                        $date_naissance = "0000/00/00";
                    }

                    $date = date_diff(date_create($date_naissance),date_create(date("Y-m-d")))->format('%R%a');//difference entre 2 dates

                    if($date < 0 OR $date > 45580)
                    {
                        print("<br>Veuillez entrer une date de naissance valide");
                        $erreur=true;
                    }

                    $requete = "SELECT ville_code_postal FROM villes_france_free WHERE ville_code_postal = '{$cp}'";
                    $resultat = mysqli_query($connexion,$requete) or die ("Exécution de la requête impossible ".mysqli_error($connexion));

                    if(mysqli_num_rows($resultat)==0)
                    {
                        print("<br>Code postal non reconnu, vérifiez d'avoir rentré un code postal valide");
                        $erreur=true;
                    }

                    if(!$erreur)
                    {
                        //cree un compte
                        $requete = "INSERT INTO table_login (utilisateur,mot_de_passe,nom,prenom,date_naissance,cp,sexe,date_inscription,choix) VALUES ('{$utilisateur}','{$mdp}','{$nom}','{$prenom}','{$date_naissance}','{$cp}','{$sexe}',CURDATE(),'0')";
                        $resultat = mysqli_query($connexion,$requete) or die ("Exécution de la requête impossible ".mysqli_error($connexion));
                        
                        if($resultat===TRUE)//si l'inscription a bien marche
                        {
                            header('Location: connexion.php');
                        }
                        else
                        {
                            print("<br>Une erreur est survenue lors de l'inscription, vérifiez d'avoir bien rempli tous les champs");
                        }
                    }
                }
                // Déconnexion
                mysqli_close($connexion);

            ?>
    </body>
</html> 