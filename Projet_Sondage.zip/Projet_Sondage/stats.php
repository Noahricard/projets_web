<?php

    session_start();

    if(!isset($_SESSION["utilisateur"]))
    {
        header("Location: connexion.php");
        exit();
    }
?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="style/style.css"><!--inclure le css-->
        <title>Statistiques</title>
    </head>

    <body>
        <?php
            include 'connexionbd.php';

        //Camembert général
            //retourne les lignes dans lesquelles choix=Barcelone
            $requete = "SELECT choix FROM table_login WHERE choix = 'Barcelone'";
            $resultat = mysqli_query($connexion,$requete) or die ("Exécution de la requête impossible ".mysqli_error($connexion));

            $nbrBarcelone = mysqli_num_rows($resultat);//nBarcelonebre de lignes trouvees pour vote Barcelone

            //retourne les lignes dans lesquelles choix=Real_Madrid
            $requete = "SELECT choix FROM table_login WHERE choix = 'Real_Madrid'";
            $resultat = mysqli_query($connexion,$requete) or die ("Exécution de la requête impossible ".mysqli_error($connexion));

            $nbrReal_Madrid = mysqli_num_rows($resultat);//nBarcelonebre de lignes trouvees pour vote Real_Madrid

            $nbrtotal = $nbrReal_Madrid+$nbrBarcelone;

            $Barcelonecam = 360*$nbrBarcelone/($nbrtotal);//convertit le nBarcelonebre de votes pour Barcelone en degres
            $Barcelonepcent = 100*$nbrBarcelone/($nbrtotal);//convertit le nBarcelonebre de votes pour l'Barcelone en %

            $Real_Madridpcent = 100*$nbrReal_Madrid/($nbrtotal);

            $image = imagecreate(300, 300);//definition de la taille de l'image

            // Couleur de fond (blanc)
            $background = imagecolorallocate($image, 0xFF, 0xFF, 0xFF);

            // Définition de quelques couleurs
            $red = imagecolorallocate($image, 0xFF, 0x00, 0x00);
            $blue = imagecolorallocate($image, 0x00, 0x00, 0xFF);

            // Dessine un arc partiel et le remplit
            imagefilledarc($image, 150, 150, 300, 300, 0, $Barcelonecam, $blue, IMG_ARC_PIE);
            imagefilledarc($image, 150, 150, 300, 300, $Barcelonecam, 360, $red, IMG_ARC_PIE);

            //creation de l'image
            imagepng($image, "camemberts/allvote.png");

            // affichage en sortie
            print('<div id="content"><h1>Resultat global :</h1>');
            print('<img src="camemberts/allvote.png"/>');

            print("<p id='blueBarcelone'>Votes pour le Barcelone : " .$nbrBarcelone ." (".$Barcelonepcent."%)</p>");
            print("<p id='redBarcelone'>Votes pour le Real_Madrid : " .$nbrReal_Madrid ." (".$Real_Madridpcent."%)</p></div>");

        //camembert sexe
          //Barcelone
            //retourne les lignes dans lesquelles choix=Barcelone et sexe = homme
            $requete = "SELECT choix FROM table_login WHERE choix = 'Barcelone' AND sexe = 'homme'";
            $resultat = mysqli_query($connexion,$requete) or die ("Exécution de la requête impossible ".mysqli_error($connexion));

            $nbrhBarcelone = mysqli_num_rows($resultat);//nBarcelonebre de lignes trouvees

            //retourne les lignes dans lesquelles choix=Barcelone et sexe = femme
            $requete = "SELECT choix FROM table_login WHERE choix = 'Barcelone' AND sexe = 'femme'";
            $resultat = mysqli_query($connexion,$requete) or die ("Exécution de la requête impossible ".mysqli_error($connexion));

            $nbrfBarcelone = mysqli_num_rows($resultat);
          //Real_Madrid
            //retourne les lignes dans lesquelles choix=Real_Madrid et sexe = homme
            $requete = "SELECT choix FROM table_login WHERE choix = 'Real_Madrid' AND sexe = 'homme'";
            $resultat = mysqli_query($connexion,$requete) or die ("Exécution de la requête impossible ".mysqli_error($connexion));

            $nbrhReal_Madrid = mysqli_num_rows($resultat);//nBarcelonebre de lignes trouvees

            //retourne les lignes dans lesquelles choix=Real_Madrid et sexe = femme
            $requete = "SELECT choix FROM table_login WHERE choix = 'Real_Madrid' AND sexe = 'femme'";
            $resultat = mysqli_query($connexion,$requete) or die ("Exécution de la requête impossible ".mysqli_error($connexion));

            $nbrfReal_Madrid = mysqli_num_rows($resultat);

            $nbrtotal = $nbrfBarcelone+$nbrhBarcelone+$nbrfReal_Madrid+$nbrhReal_Madrid;

            $currenttot = $nbrhBarcelone;

            $hBarcelonecam = 360*$currenttot/($nbrtotal);
            $hBarcelonepcent = 100*$nbrhBarcelone/($nbrtotal);

            $currenttot = $currenttot + $nbrhReal_Madrid;

            $hReal_Madridcam = 360*$currenttot/($nbrtotal);
            $hReal_Madridpcent = 100*$nbrhReal_Madrid/($nbrtotal);

            $currenttot = $currenttot + $nbrfBarcelone;

            $fBarcelonecam = 360*$currenttot/($nbrtotal);
            $fBarcelonepcent = 100*$nbrfBarcelone/($nbrtotal);

            $fReal_Madridpcent = 100*$nbrfReal_Madrid/($nbrtotal);
            
            $image = imagecreate(280, 280);

            // Couleur de fond (blanc)
            $background = imagecolorallocate($image, 0xFF, 0xFF, 0xFF);

            $blueBarcelone = imagecolorallocate($image, 0x00, 0x00, 0xFF);
            $redBarcelone = imagecolorallocate($image, 0xFF, 0x00, 0x00);
            
            $blueReal_Madrid = imagecolorallocate($image, 0x00, 0x00, 0x7F);
            $redReal_Madrid = imagecolorallocate($image, 0x7F, 0x00, 0x00);

            // Dessine un arc partiel et le remplit si il a une valeur supérieure à 0
            if($hBarcelonecam!=0)imagefilledarc($image, 140, 140, 280, 280, 0, $hBarcelonecam, $blueBarcelone, IMG_ARC_PIE);
            if($hBarcelonecam!=$hReal_Madridcam)imagefilledarc($image, 140, 140, 280, 280, $hBarcelonecam, $hReal_Madridcam, $blueReal_Madrid, IMG_ARC_PIE);
            if($hReal_Madridcam!=$fBarcelonecam)imagefilledarc($image, 140, 140, 280, 280, $hReal_Madridcam, $fBarcelonecam, $redBarcelone, IMG_ARC_PIE);
            if($fBarcelonecam!=360)imagefilledarc($image, 140, 140, 280, 280, $fBarcelonecam, 360, $redReal_Madrid, IMG_ARC_PIE);     

            imagepng($image, "camemberts/sexeReal_Madridvote.png");

            print('<div id="content"><h1>Resultat en fonction du sexe :</h1>');
            print('<img src="camemberts/sexeReal_Madridvote.png"/>');

            print("<h2>Barcelone :</h2>");
            print("<p id='blueBarcelone'>Hommes : " .$nbrhBarcelone ." (".$hBarcelonepcent."%)</p>");
            print("<p id='redBarcelone'>Femmes : " .$nbrfBarcelone ." (".$fBarcelonepcent."%)</p>");

            print("<h2>Real_Madrid :</h2>");
            print("<p id='blueReal_Madrid'>Hommes : " .$nbrhReal_Madrid ." (".$hReal_Madridpcent."%)</p>");
            print("<p id='redReal_Madrid'>Femmes : " .$nbrfReal_Madrid ." (".$fReal_Madridpcent."%)</p></div>");
        //camembert age
          //Barcelone
            //retourne les lignes pour lesquelles l'age est inferieur a 18 et vote pour Barcelone
            $requete = "SELECT * FROM table_login WHERE choix = 'Barcelone' AND TIMESTAMPDIFF(YEAR, date_naissance, CURDATE())<18";
            $resultat = mysqli_query($connexion,$requete) or die ("Exécution de la requête impossible ".mysqli_error($connexion));

            $nbrjeunesBarcelone = mysqli_num_rows($resultat);//nBarcelonebre de lignes trouvees

            //retourne les lignes pour lesquelles l'age est compris entre 18 et 25 et vote pour Barcelone
            $requete = "SELECT * FROM table_login WHERE choix = 'Barcelone' AND TIMESTAMPDIFF(YEAR, date_naissance, CURDATE())>=18 AND TIMESTAMPDIFF(YEAR, date_naissance, CURDATE())<25";
            $resultat = mysqli_query($connexion,$requete) or die ("Exécution de la requête impossible ".mysqli_error($connexion));

            $nbradultesBarcelone = mysqli_num_rows($resultat);

            //retourne les lignes pour lesquelles l'age est superieur a 25 et vote pour Barcelone
            $requete = "SELECT * FROM table_login WHERE choix = 'Barcelone' AND TIMESTAMPDIFF(YEAR, date_naissance, CURDATE())>=25";
            $resultat = mysqli_query($connexion,$requete) or die ("Exécution de la requête impossible ".mysqli_error($connexion));

            $nbrvieuxBarcelone = mysqli_num_rows($resultat);

          //Real_Madrid
            //retourne les lignes pour lesquelles l'age est inferieur a 18 et vote pour Real_Madrid
            $requete = "SELECT * FROM table_login WHERE choix = 'Real_Madrid' AND TIMESTAMPDIFF(YEAR, date_naissance, CURDATE())<18";
            $resultat = mysqli_query($connexion,$requete) or die ("Exécution de la requête impossible ".mysqli_error($connexion));

            $nbrjeunesReal_Madrid = mysqli_num_rows($resultat);//nBarcelonebre de lignes trouvees

            //retourne les lignes pour lesquelles l'age est cBarcelonepris entre 18 et 25 et vote pour Real_Madrid
            $requete = "SELECT * FROM table_login WHERE choix = 'Real_Madrid' AND TIMESTAMPDIFF(YEAR, date_naissance, CURDATE())>=18 AND TIMESTAMPDIFF(YEAR, date_naissance, CURDATE())<25";
            $resultat = mysqli_query($connexion,$requete) or die ("Exécution de la requête impossible ".mysqli_error($connexion));

            $nbradultesReal_Madrid = mysqli_num_rows($resultat);

            //retourne les lignes pour lesquelles l'age est superieur a 25 et vote pour Real_Madrid
            $requete = "SELECT * FROM table_login WHERE choix = 'Real_Madrid' AND TIMESTAMPDIFF(YEAR, date_naissance, CURDATE())>=25";
            $resultat = mysqli_query($connexion,$requete) or die ("Exécution de la requête impossible ".mysqli_error($connexion));

            $nbrvieuxReal_Madrid = mysqli_num_rows($resultat);

            $nrbtotal = $nbrjeunesBarcelone+$nbradultesBarcelone+$nbrvieuxBarcelone+$nbrjeunesReal_Madrid+$nbradultesReal_Madrid+$nbrvieuxReal_Madrid;
            
            $currenttot = $nbrjeunesBarcelone;

            $jeunesBarcelonecam = 360*$currenttot/$nrbtotal;
            $jeunesBarcelonepcent = 100*$nbrjeunesBarcelone/$nrbtotal;

            $currenttot = $currenttot + $nbrjeunesReal_Madrid;

            $jeunesReal_Madridcam = 360*$currenttot/$nrbtotal;
            $jeunesReal_Madridpcent = 100*$nbrjeunesReal_Madrid/$nrbtotal;

            $currenttot = $currenttot + $nbradultesBarcelone;

            $adultesBarcelonecam = 360*$currenttot/$nrbtotal;
            $adultesBarcelonepcent = 100*$nbradultesBarcelone/$nrbtotal;

            $currenttot = $currenttot + $nbradultesReal_Madrid;

            $adultesReal_Madridcam = 360*$currenttot/$nrbtotal;
            $adultesReal_Madridpcent = 100*$nbradultesReal_Madrid/$nrbtotal;

            $currenttot = $currenttot + $nbrvieuxBarcelone;

            $vieuxBarcelonecam = 360*$currenttot/$nbrtotal;
            $vieuxBarcelonepcent = 100*$nbrvieuxBarcelone/$nrbtotal;

            $vieuxReal_Madridpcam = 360*$nbrvieuxReal_Madrid/$nrbtotal;
            $vieuxReal_Madridpcent = 100*$nbrvieuxReal_Madrid/$nrbtotal;

            $image = imagecreate(280, 280);

            // Couleur de fond (blanc)
            $background = imagecolorallocate($image, 0xFF, 0xFF, 0xFF);

            // Définition de quelques couleurs
            $blueBarcelone = imagecolorallocate($image, 0x00, 0x00, 0xFF);
            $redBarcelone = imagecolorallocate($image, 0xFF, 0x00, 0x00);
            $greenBarcelone = imagecolorallocate($image, 0x00, 0xFF, 0x00);
            
            $blueReal_Madrid = imagecolorallocate($image, 0x00, 0x00, 0x7F);
            $redReal_Madrid = imagecolorallocate($image, 0x7F, 0x00, 0x00);
            $greenReal_Madrid = imagecolorallocate($image, 0x00, 0x7F, 0x00);          

            // Dessine un arc partiel et le remplit
            if($jeunesBarcelonecam!=0)imagefilledarc($image, 140, 140, 280, 280, 0, $jeunesBarcelonecam, $blueBarcelone, IMG_ARC_PIE);
            if($jeunesBarcelonecam!=$jeunesReal_Madridcam)imagefilledarc($image, 140, 140, 280, 280, $jeunesBarcelonecam, $jeunesReal_Madridcam, $blueReal_Madrid, IMG_ARC_PIE);
            if($jeunesReal_Madridcam!=$adultesBarcelonecam)imagefilledarc($image, 140, 140, 280, 280, $jeunesReal_Madridcam, $adultesBarcelonecam, $redBarcelone, IMG_ARC_PIE);
            if($adultesBarcelonecam!=$adultesReal_Madridcam)imagefilledarc($image, 140, 140, 280, 280, $adultesBarcelonecam, $adultesReal_Madridcam, $redReal_Madrid, IMG_ARC_PIE);
            if($adultesReal_Madridcam!=$vieuxBarcelonecam)imagefilledarc($image, 140, 140, 280, 280, $adultesReal_Madridcam, $vieuxBarcelonecam, $greenBarcelone, IMG_ARC_PIE);
            if($vieuxBarcelonecam!=360)imagefilledarc($image, 140, 140, 280, 280, $vieuxBarcelonecam, 360, $greenReal_Madrid, IMG_ARC_PIE);
            
            imagepng($image, "camemberts/sexevote.png");

            print('<div id="content"><h1>Resultat en fonction de l\'âge :</h1>');            
            print('<img src="camemberts/sexevote.png"/>');

            print("<h2>Barcelone :</h2>");
            print("<p id='blueBarcelone'>Jeunes (-18) : " .$nbrjeunesBarcelone ." (".$jeunesBarcelonepcent."%)</p>");
            print("<p id='redBarcelone'>Adultes (18-25) : " .$nbradultesBarcelone ." (".$adultesBarcelonepcent."%)</p>");
            print("<p id='greenBarcelone'>Adultes (+25ans) : " .$nbrvieuxBarcelone ." (".$vieuxBarcelonepcent."%)</p>");

            print("<h2>Real_Madrid :</h2>");
            print("<p id='blueReal_Madrid'>Jeunes (-18) : " .$nbrjeunesReal_Madrid ." (".$jeunesReal_Madridpcent."%)</p>");
            print("<p id='redReal_Madrid'>Adultes (18-25) : " .$nbradultesReal_Madrid ." (".$adultesReal_Madridpcent."%)</p>");
            print("<p id='greenReal_Madrid'>Adultes (+25ans) : " .$nbrvieuxReal_Madrid ." (".$vieuxReal_Madridpcent."%)</p></div>");

            // Déconnexion
            mysqli_close($connexion);

        ?>

        <form method="post" action="questionnaire.php">
            <input id="center" class="button" type="submit" value="Recommencer le questionnaire">
        </form>
        <form method="post" action="deconnexion.php">
            <input id="center" class="button" type="submit" value="Deconnexion">
        </form>
    </body>
</html> 