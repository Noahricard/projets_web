<?php

    session_start();

    if(!isset($_SESSION["utilisateur"]))
    {
        header("Location: connexion.php");
        exit();
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="style/style.css"><!--inclure le css-->
        <title>Accueil</title>
    </head>

    <body id="group" class="groupbutton">
        <div id="content">
        <form method="post" action="stats.php">
            <input class="button" id="center" type="submit" value="Résultats">
        </form>
        <form method="post" action="questionnaire.php">
            <input class="button" id="center" type="submit" value="Commencer le questionnaire">
        </form>
        <form method="post" action="deconnexion.php">
            <input class="button" id="center" type="submit" value="Déconnexion">
        </form>
    </div>
    </body>
</html> 